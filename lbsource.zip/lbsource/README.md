Lightbit Core
=====================================

https://lightbit.xyz

What is Lightbit?
----------------

Lightbit is an experimental digital currency that enables instant payments to
anyone, anywhere in the world. Lightbit uses peer-to-peer technology to operate
with no central authority: managing transactions and issuing money are carried
out collectively by the network. Lightbit Core is the name of open source
software which enables the use of this currency.

For more information, as well as an immediately useable, binary version of
the Lightbit Core software, see https://github.com/lightbit/lightbit/releases.

License
-------

Lightbit Core is released under the terms of the MIT license. See [COPYING](COPYING) for more
information or see https://opensource.org/licenses/MIT.
